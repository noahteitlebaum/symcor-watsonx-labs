from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Optional

app = FastAPI(title="Honda Quotation Tool API")

# Honda models data with pricing information
HONDA_MODELS = {
    "Honda Civic": {
        "base_price": 28000,
        "description": "Compact sedan with excellent fuel efficiency",
        "available_provinces": ["ON", "QC", "BC", "AB", "MB", "SK", "NS", "NB", "PE", "NL"],
        "lease_terms": [24, 36, 48, 60],
        "min_down_payment": 2000
    },
    "Honda CR-V": {
        "base_price": 35000,
        "description": "Compact SUV with spacious interior",
        "available_provinces": ["ON", "QC", "BC", "AB", "MB", "SK", "NS", "NB", "PE", "NL"],
        "lease_terms": [24, 36, 48, 60],
        "min_down_payment": 3000
    },
    "Honda Accord": {
        "base_price": 32000,
        "description": "Midsize sedan with advanced safety features",
        "available_provinces": ["ON", "QC", "BC", "AB", "MB", "SK", "NS", "NB", "PE", "NL"],
        "lease_terms": [24, 36, 48, 60],
        "min_down_payment": 2500
    },
    "Honda Pilot": {
        "base_price": 48000,
        "description": "Three-row SUV perfect for families",
        "available_provinces": ["ON", "QC", "BC", "AB", "MB", "SK", "NS", "NB", "PE", "NL"],
        "lease_terms": [24, 36, 48, 60],
        "min_down_payment": 4000
    }
}


class QuotationRequest(BaseModel):
    model: str
    intent: str  # e.g., "lease", "purchase", "finance"
    province: str
    lease_term: int  # in months
    down_payment: float


class QuotationResponse(BaseModel):
    model: str
    intent: str
    province: str
    lease_term: int
    down_payment: float
    base_price: float
    monthly_payment: float
    total_cost: float
    description: str
    status: str
    message: Optional[str] = None


def calculate_monthly_payment(base_price: float, down_payment: float, lease_term: int, intent: str) -> float:
    """Calculate monthly payment based on intent type"""
    remaining_amount = base_price - down_payment
    
    if intent.lower() == "lease":
        # Lease calculation with interest rate
        interest_rate = 0.04  # 4% annual interest
        monthly_rate = interest_rate / 12
        monthly_payment = (remaining_amount * monthly_rate * (1 + monthly_rate) ** lease_term) / \
                         ((1 + monthly_rate) ** lease_term - 1)
    elif intent.lower() in ["purchase", "finance"]:
        # Finance calculation with interest rate
        interest_rate = 0.05  # 5% annual interest
        monthly_rate = interest_rate / 12
        monthly_payment = (remaining_amount * monthly_rate * (1 + monthly_rate) ** lease_term) / \
                         ((1 + monthly_rate) ** lease_term - 1)
    else:
        # Simple division for other intents
        monthly_payment = remaining_amount / lease_term
    
    return round(monthly_payment, 2)


@app.get("/")
async def root():
    """Root endpoint with API information"""
    return {
        "message": "Honda Quotation Tool API",
        "version": "1.0.0",
        "endpoints": {
            "quotation": "/quotation_tool",
            "models": "/models"
        }
    }


@app.get("/models")
async def get_models():
    """Get all available Honda models"""
    return {
        "available_models": list(HONDA_MODELS.keys()),
        "models_details": HONDA_MODELS
    }


@app.post("/quotation_tool", response_model=QuotationResponse)
async def quotation_tool(request: QuotationRequest):
    """
    Generate a quotation for a Honda vehicle
    
    Parameters:
    - model: Honda model name (Honda Civic, Honda CR-V, Honda Accord, Honda Pilot)
    - intent: Purchase intent (lease, purchase, finance)
    - province: Canadian province code (ON, QC, BC, AB, etc.)
    - lease_term: Lease term in months (24, 36, 48, 60)
    - down_payment: Down payment amount in CAD
    """
    
    # Validate model
    if request.model not in HONDA_MODELS:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid model. Available models: {', '.join(HONDA_MODELS.keys())}"
        )
    
    model_data = HONDA_MODELS[request.model]
    
    # Validate province
    if request.province.upper() not in model_data["available_provinces"]:
        raise HTTPException(
            status_code=400,
            detail=f"Model not available in {request.province}. Available provinces: {', '.join(model_data['available_provinces'])}"
        )
    
    # Validate lease term
    if request.lease_term not in model_data["lease_terms"]:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid lease term. Available terms: {', '.join(map(str, model_data['lease_terms']))} months"
        )
    
    # Validate down payment
    if request.down_payment < model_data["min_down_payment"]:
        raise HTTPException(
            status_code=400,
            detail=f"Down payment must be at least ${model_data['min_down_payment']}"
        )
    
    if request.down_payment >= model_data["base_price"]:
        raise HTTPException(
            status_code=400,
            detail=f"Down payment cannot exceed base price of ${model_data['base_price']}"
        )
    
    # Calculate monthly payment
    monthly_payment = calculate_monthly_payment(
        model_data["base_price"],
        request.down_payment,
        request.lease_term,
        request.intent
    )
    
    # Calculate total cost
    total_cost = request.down_payment + (monthly_payment * request.lease_term)
    
    return QuotationResponse(
        model=request.model,
        intent=request.intent,
        province=request.province.upper(),
        lease_term=request.lease_term,
        down_payment=request.down_payment,
        base_price=model_data["base_price"],
        monthly_payment=monthly_payment,
        total_cost=round(total_cost, 2),
        description=model_data["description"],
        status="success",
        message=f"Quotation generated successfully for {request.model}"
    )


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)

# Made with Bob
