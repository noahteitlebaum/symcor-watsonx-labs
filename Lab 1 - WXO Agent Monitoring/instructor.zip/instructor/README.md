# Honda Quotation Tool API

A FastAPI application that provides vehicle quotation services for Honda models.

## Features

- **Quotation Tool Endpoint**: Generate quotations for Honda vehicles based on model, intent, province, lease term, and down payment
- **Model Information**: Retrieve details about available Honda models
- **Input Validation**: Comprehensive validation for all input parameters
- **Monthly Payment Calculation**: Automatic calculation based on lease/finance terms

## Available Honda Models

1. **Honda Civic** - Compact sedan with excellent fuel efficiency (Base: $28,000)
2. **Honda CR-V** - Compact SUV with spacious interior (Base: $35,000)
3. **Honda Accord** - Midsize sedan with advanced safety features (Base: $32,000)
4. **Honda Pilot** - Three-row SUV perfect for families (Base: $48,000)

## Installation

### Option 1: Local Installation

1. Install dependencies:
```bash
pip install -r requirements.txt
```

2. Start the server:
```bash
python main.py
```

Or using uvicorn directly:
```bash
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

The API will be available at `http://localhost:8000`

### Option 2: Docker Installation

#### Using Docker

1. Build the Docker image:
```bash
docker build -t honda-quotation-api .
```

2. Run the container:
```bash
docker run -d -p 8000:8000 --name honda-quotation-tool honda-quotation-api
```

3. Check container status:
```bash
docker ps
```

4. View logs:
```bash
docker logs honda-quotation-tool
```

5. Stop the container:
```bash
docker stop honda-quotation-tool
```

6. Remove the container:
```bash
docker rm honda-quotation-tool
```

#### Using Docker Compose (Recommended)

1. Start the service:
```bash
docker-compose up -d
```

2. Check status:
```bash
docker-compose ps
```

3. View logs:
```bash
docker-compose logs -f
```

4. Stop the service:
```bash
docker-compose down
```

The API will be available at `http://localhost:8000`

## API Endpoints

### 1. Root Endpoint
```
GET /
```
Returns API information and available endpoints.

### 2. Get Models
```
GET /models
```
Returns all available Honda models with their details.

**Response Example:**
```json
{
  "available_models": ["Honda Civic", "Honda CR-V", "Honda Accord", "Honda Pilot"],
  "models_details": {
    "Honda Civic": {
      "base_price": 28000,
      "description": "Compact sedan with excellent fuel efficiency",
      "available_provinces": ["ON", "QC", "BC", "AB", "MB", "SK", "NS", "NB", "PE", "NL"],
      "lease_terms": [24, 36, 48, 60],
      "min_down_payment": 2000
    }
  }
}
```

### 3. Quotation Tool (Main Endpoint)
```
POST /quotation_tool
```

**Request Body:**
```json
{
  "model": "Honda Civic",
  "intent": "lease",
  "province": "ON",
  "lease_term": 36,
  "down_payment": 5000
}
```

**Parameters:**
- `model` (string, required): Honda model name
  - Options: "Honda Civic", "Honda CR-V", "Honda Accord", "Honda Pilot"
- `intent` (string, required): Purchase intent
  - Options: "lease", "purchase", "finance"
- `province` (string, required): Canadian province code
  - Options: "ON", "QC", "BC", "AB", "MB", "SK", "NS", "NB", "PE", "NL"
- `lease_term` (integer, required): Lease term in months
  - Options: 24, 36, 48, 60
- `down_payment` (float, required): Down payment amount in CAD
  - Must be >= minimum down payment for the model
  - Must be < base price of the model

**Response Example:**
```json
{
  "model": "Honda Civic",
  "intent": "lease",
  "province": "ON",
  "lease_term": 36,
  "down_payment": 5000,
  "base_price": 28000,
  "monthly_payment": 678.91,
  "total_cost": 29440.76,
  "description": "Compact sedan with excellent fuel efficiency",
  "status": "success",
  "message": "Quotation generated successfully for Honda Civic"
}
```

## Usage Examples

### Using cURL

```bash
# Get all models
curl http://localhost:8000/models

# Generate a quotation
curl -X POST http://localhost:8000/quotation_tool \
  -H "Content-Type: application/json" \
  -d '{
    "model": "Honda CR-V",
    "intent": "lease",
    "province": "ON",
    "lease_term": 48,
    "down_payment": 4000
  }'
```

### Using Python requests

```python
import requests

# Get models
response = requests.get("http://localhost:8000/models")
print(response.json())

# Generate quotation
quotation_data = {
    "model": "Honda Accord",
    "intent": "finance",
    "province": "BC",
    "lease_term": 60,
    "down_payment": 3000
}

response = requests.post(
    "http://localhost:8000/quotation_tool",
    json=quotation_data
)
print(response.json())
```

## Interactive API Documentation

FastAPI provides automatic interactive API documentation:

- **Swagger UI**: http://localhost:8000/docs
- **ReDoc**: http://localhost:8000/redoc

## Validation Rules

1. **Model**: Must be one of the four available Honda models
2. **Province**: Must be a valid Canadian province code where the model is available
3. **Lease Term**: Must be 24, 36, 48, or 60 months
4. **Down Payment**: 
   - Must be >= minimum down payment for the selected model
   - Must be < base price of the model

## Payment Calculation

The API calculates monthly payments based on the intent:

- **Lease**: 4% annual interest rate
- **Purchase/Finance**: 5% annual interest rate

Formula: Standard amortization formula with compound interest

## Error Handling

The API returns appropriate HTTP status codes and error messages:

- `400 Bad Request`: Invalid input parameters
- `422 Unprocessable Entity`: Invalid request format

Example error response:
```json
{
  "detail": "Invalid model. Available models: Honda Civic, Honda CR-V, Honda Accord, Honda Pilot"
}
```

## Uploading to watsonx Orchestrate

The API includes an OpenAPI specification file ([`openapi.json`](openapi.json)) that can be uploaded to watsonx Orchestrate as a tool.

### Steps to Upload:

1. **Ensure the API is accessible**: Make sure your FastAPI server is running and accessible from watsonx Orchestrate. If running locally, you may need to use a tunneling service like ngrok or deploy to a public server.

2. **Update the server URL in openapi.json**:
   - Open [`openapi.json`](openapi.json)
   - Update the `servers[0].url` field to your actual server URL
   - Example: `"url": "https://your-server.com"` or `"url": "https://your-ngrok-url.ngrok.io"`

3. **Upload to watsonx Orchestrate**:
   - Log in to watsonx Orchestrate
   - Navigate to the Tools section
   - Click "Add Tool" or "Import Tool"
   - Select "OpenAPI" as the tool type
   - Upload the [`openapi.json`](openapi.json) file
   - Configure authentication if required
   - Save and deploy the tool

4. **Use in Agents**:
   - Once uploaded, the quotation_tool endpoint will be available as a tool
   - You can add it to your agents to enable vehicle quotation capabilities
   - The tool will accept the required parameters (model, intent, province, lease_term, down_payment)
   - It will return complete quotation details including monthly payment and total cost

### Example Usage in watsonx Orchestrate:

Once configured, you can ask your agent questions like:
- "Generate a quotation for a Honda Civic lease in Ontario for 36 months with $5000 down payment"
- "What would be the monthly payment for a Honda Pilot financed over 48 months in BC with $8000 down?"
- "Show me all available Honda models"

## License

This is a demonstration API for educational purposes.